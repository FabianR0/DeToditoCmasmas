template<typename T>
class List {
private:
    class Node {
    private:
        T data;
        Node* next;
    public:
   
    };
    Node* head;
    Node* tail;
public:
    List() {
        head = nullptr;
        tail = nullptr;
        //cout << "Hola desde el constructor de lista" << endl;
    }
    bool empty() {
        return head == nullptr && tail == nullptr;
    }
    void push_back(T elem) {
        Node *n = new Node(elem);
        if(empty()) {
            head = n;
            tail = n;
        } else {
            tail->setNext(n);
            tail = n;
        }
    }

};
int main(){
	return 0;
}
